#!/bin/bash
# Install's puppet under RHEL

e() {
  echo "$0: $@"
}
err() {
  >&2 e "Error: $@"
}

if [[ $EUID -ne 0 ]]; then
  err "This script must be run as root"
  exit 1
fi

# Connect to CUIT RHEL Satellite
yum clean all
yum -y install http://satellite1.cc.columbia.edu/pub/katello-ca-consumer-latest.noarch.rpm
subscription-manager unregister
subscription-manager register --org="CUIT" --activationkey="Standard RHEL6 Activation Key"
pool=`subscription-manager list --available --pool-only --matches='EPEL 6'`
subscription-manager attach --pool $pool
pool=`subscription-manager list --available --pool-only --matches='CUIT Custom RPMS'`
subscription-manager attach --pool $pool
# install the PE agent package
yum install -y puppet-agent
