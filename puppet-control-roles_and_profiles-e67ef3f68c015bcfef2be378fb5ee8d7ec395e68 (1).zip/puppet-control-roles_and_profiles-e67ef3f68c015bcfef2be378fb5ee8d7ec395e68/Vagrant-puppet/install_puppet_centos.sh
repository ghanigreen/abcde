#!/bin/bash

e() {
  echo "$0: $@"
}
err() {
  >&2 e "Error: $@"
}

if [[ $EUID -ne 0 ]]; then
  err "This script must be run as root"
  exit 1
fi

if [ -f '/etc/redhat-release' ]; then

    yum install -y redhat-lsb-core

    case "$(lsb_release -sr | cut -d'.' -f1)" in

        6)
            ;;
        *)
            err "Unsupported Operating System Version"
            exit 1
            ;;
    esac
else
    err "Unsupported Operating System Version"
    exit 1
fi

yum install -y http://download.fedoraproject.org/pub/epel/6/x86_64/epel-release-6-8.noarch.rpm
yum install -y https://yum.puppetlabs.com/puppetlabs-release-el-6.noarch.rpm
# Connect to CUIT RHEL Satellite
# See: http://serverfault.com/questions/506148/is-subscription-manager-available-for-centos
wget -q -O /etc/yum.repos.d/epel-rhsm.repo http://repos.fedorapeople.org/repos/candlepin/subscription-manager/epel-subscription-manager.repo
yum install -y subscription-manager
# And these instructions: https://wiki.cc.columbia.edu/unix:manual:satellite
yum -y install http://satellite1.cc.columbia.edu/pub/katello-ca-consumer-latest.noarch.rpm
subscription-manager unregister
subscription-manager register --org="CUIT" --activationkey="Standard RHEL6 Activation Key"
# workaraound: subscription-manager is not adding the CUIT Custom Repos
pool=`subscription-manager list --available --pool-only --matches='CUIT Custom RPMS'`
sudo subscription-manager attach --pool $pool
# install the PE agent package
yum install -y puppet-agent
