#!/bin/sh
echo Installing extras for local testing of dev/oauth-server
set -x

yum install -y python-pip firefox
pip install --upgrade pip
su vagrant -c "ssh-keyscan gitlab.cc.columbia.edu >.ssh/known_hosts"
su vagrant -c "git clone git@gitlab.cc.columbia.edu:cuit-ent-arch/oauth2.git"
cd oauth2
pip install -r requirements.txt
/bin/echo 'clientP@55' | su vagrant -c "./ping_add_clients.sh https://localhost:9031"
