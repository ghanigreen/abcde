Outstanding issues:
* #INC0546333 Not all NFS homedirs are being mounted
* #INC0580159 Not all NFS app-specific storage is being mounted
* UC4 not installed yet
* Hyperic not installed yet
* Nagios not installed yet
* SOE is removed
* Kerberos auth isn't set up perfectly

