## Set up a Puppet+Vagrant Dev environment ##

###  What you need to start    ###


1. Install VirtualBox :
       [ https://www.virtualbox.org/wiki/Downloads]( https://www.virtualbox.org/wiki/Downloads "vbox download")

2. Install Vagrant :
       [http://www.vagrantup.com/downloads.html]( http://www.vagrantup.com/downloads.html)

3. If you're running Windows you will need to install Cygwin.
       [https://cygwin.com/install.html](https://cygwin.com/install.html)
   - Try to install cygwin in a directory with no spaces in the name. So no “Program Files” or anything like that. The best location would be C:\Cygwin

   - **Make sure to install tools like : **
		- wget
		- curl
		- dos2unix
		- ruby


4. Install Git :  [http://git-scm.com/downloads](http://git-scm.com/downloads)

    - If you're on OSX. The installer on the website seems to be broken. As a workaround, use homebrew to install Git.
        - install Homebrew : [http://brew.sh/](http://brew.sh/)

			 `ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"`
        - install Git itself :
            `brew install git`

	- If  you're on Windows, during the install you'll  have the option to add Git  and its Linux-style command line tools to your system Path. If you already have Git installed, or you forgot to select this option upon installation, you’ll need to add Git’s /bin directory to your Path manually.
ie: `set PATH=%PATH%;/cygdrive/c/Program\ Files\ \(x86\)/Git/bin/`


5. Set up ssh keys:
	- `% ssh-keygen -t rsa`

	this will place both private and public keys to  ~/.ssh/id_rsa and ~/.ssh/id_rsa.pub  respectively.

   - Place the public key in the Git Server
     << this is still in the works  >>

6. Once everything is installed and configured <pre><code>git clone git@gitlab.com:leshiynyc/puppet-control.git
	cd puppet-control
	vagrant up puppetagent1
	vagrant ssh puppetagent1
    </code></pre>


7. The repo above contains the 'Vagrantfile', which is the configuration file for vagrant as well as the following provisioning scripts for vagrant.

   <pre><code>   ( ./puppet-control/vagrant/fullstack.sh )
   ( ./puppet-control/vagrant/allinone.sh )</code></pre>


8.To get Hiera to work on Vagrant w/o a Puppet Master
<pre><code>    vagrant ssh puppetagent1
    sudo su -
    cp -v /vagrant/site/profile/files/hiera.yaml  /etc/puppetlabs/puppet/
    rm -rf /etc/puppetlabs/puppet/environments/production/
    ln -s /vagrant  /etc/puppetlabs/puppet/environments/production
    puppet apply -e  "include CLASS_NAME"</code></pre>
**CLASS_NAME is the class which uses hiera, ie 'profile::base::ntp'**

**Gotchas**

- if you lose network connectivity on your laptop ( it goes to sleep or you close the lid), vagrant instance will lose it too and will not automatically regain it. You will need to ssh to your instance and restart networking

`/etc/init.d/network restart`

or

`$ service network restart`



On Cygwin  `git commit` will not open vi/vim and just hangs. This is how you fix it. Hopefully you’ve installed Cygwin as mentioned above, in `C:\cygwin`. run:
`git config --global core.editor "'C:\Cygwin\bin\vim.exe'"`

 **notice the single quotes within  double quotes**

Execute this command if you want to use Sublime Text as your core.editor 
`git config --global core.editor "'c:/program files/sublime text 2/sublime_text.exe' -w"`




**Useful and Helpful :**

   - Clone the following git repo with some extra tools to help with the environment :
`git clone git@gitlab.com:leshiynyc/tools.git`

  Instructions are in the README.md file.


**Vagrant Boxes.**

- Windows Boxes

[http://vagrantbox.msopentech.com/](http://vagrantbox.msopentech.com/)

[https://vagrantcloud.com/opentable/boxes/win-2008r2-standard-amd64-nocm](https://vagrantcloud.com/opentable/boxes/win-2008r2-standard-amd64-nocm)

- Linux Boxes

[http://puppet-vagrant-boxes.puppetlabs.com/](http://puppet-vagrant-boxes.puppetlabs.com/)

[http://www.vagrantbox.es/](http://www.vagrantbox.es/)

**Editors and IDEs.**

- Sublime Text

[https://www.sublimetext.com/](https://www.sublimetext.com/)

- Gepetto

[http://puppetlabs.com/blog/geppetto-40-here](http://puppetlabs.com/blog/geppetto-40-here)

- JetBrains RubyMine ( requires a license )

[https://www.jetbrains.com/ruby/](https://www.jetbrains.com/ruby/)

- Vi/ViM

the 'Tools' git repo from above contains .vimrc with configs for syntax

- or anything else you prefer



