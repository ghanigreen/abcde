Sample Commands to encrypt eyaml:
---------------------------------

# /opt/puppet/bin/eyaml encrypt --pkcs7-public-key=/etc/puppetlabs/puppet/keys/public_key.pkcs7.pem -s 'This is my secret.'

Output:

string: ENC[PKCS7,MIIBiQYJKoZIhvcNAQcDoIIBejCCAXYCAQAxggEhMIIBHQIBADAFMAACAQEwDQYJKoZIhvcNAQEBBQAEggEAJf534Lz/rx+IEtZCVohJohfsMENhYl7wVfzyWrrzdjcOhad8G+O4R7t3JaWH/6BR0xsjIfp6f/KeYz4RFG80xVM5QEh2wAaDEWOjTvulwIyThhQUiQwRkPLxiWnGf1jxzzjCi+Wg+95btZerVjMNoJ6vE0KiQxCG/HbNmA22IKPhpnn/KXX3dJgep5MBe8+AOk04brfIMQxguq1ttTaTu4G0gdqTOoK2AdF4TtYugE99eaWDQIMoMKo4BnDxdb7k3tQzy4CcpC2shOOCGht6bC+SMKKNOKOhgUvK8aDSZYwRfiCnL/aVPmE947IfZYlF1eHZsefGH321FJM/KbJx5TBMBgkqhkiG9w0BBwEwHQYJYIZIAWUDBAEqBBA8crBWT8dFRfkcJfEuW/1sgCCl7WZdpYGtfSjS7CA+xzW6OozS6+oFHkmatlNlP486LA==]

OR

block: >
    ENC[PKCS7,MIIBiQYJKoZIhvcNAQcDoIIBejCCAXYCAQAxggEhMIIBHQIBADAFMAACAQEw
    DQYJKoZIhvcNAQEBBQAEggEAJf534Lz/rx+IEtZCVohJohfsMENhYl7wVfzy
    WrrzdjcOhad8G+O4R7t3JaWH/6BR0xsjIfp6f/KeYz4RFG80xVM5QEh2wAaD
    EWOjTvulwIyThhQUiQwRkPLxiWnGf1jxzzjCi+Wg+95btZerVjMNoJ6vE0Ki
    QxCG/HbNmA22IKPhpnn/KXX3dJgep5MBe8+AOk04brfIMQxguq1ttTaTu4G0
    gdqTOoK2AdF4TtYugE99eaWDQIMoMKo4BnDxdb7k3tQzy4CcpC2shOOCGht6
    bC+SMKKNOKOhgUvK8aDSZYwRfiCnL/aVPmE947IfZYlF1eHZsefGH321FJM/
    KbJx5TBMBgkqhkiG9w0BBwEwHQYJYIZIAWUDBAEqBBA8crBWT8dFRfkcJfEu
    W/1sgCCl7WZdpYGtfSjS7CA+xzW6OozS6+oFHkmatlNlP486LA==]


Paste this into *.yaml file like so:

duo::conf::skey: >
    ENC[PKCS7,MIIBiQYJKoZIhvcNAQcDoIIBejCCAXYCAQAxggEhMIIBHQIBADAFMAACAQEw
    DQYJKoZIhvcNAQEBBQAEggEAJf534Lz/rx+IEtZCVohJohfsMENhYl7wVfzy
    WrrzdjcOhad8G+O4R7t3JaWH/6BR0xsjIfp6f/KeYz4RFG80xVM5QEh2wAaD
    EWOjTvulwIyThhQUiQwRkPLxiWnGf1jxzzjCi+Wg+95btZerVjMNoJ6vE0Ki
    QxCG/HbNmA22IKPhpnn/KXX3dJgep5MBe8+AOk04brfIMQxguq1ttTaTu4G0
    gdqTOoK2AdF4TtYugE99eaWDQIMoMKo4BnDxdb7k3tQzy4CcpC2shOOCGht6
    bC+SMKKNOKOhgUvK8aDSZYwRfiCnL/aVPmE947IfZYlF1eHZsefGH321FJM/
    KbJx5TBMBgkqhkiG9w0BBwEwHQYJYIZIAWUDBAEqBBA8crBWT8dFRfkcJfEu
    W/1sgCCl7WZdpYGtfSjS7CA+xzW6OozS6+oFHkmatlNlP486LA==]