## Set up a Puppet+Vagrant Dev environment ##

###  What you need to start    ###


1. Install VirtualBox :
       [ https://www.virtualbox.org/wiki/Downloads]( https://www.virtualbox.org/wiki/Downloads "vbox download")

2. Install Vagrant :
       [http://www.vagrantup.com/downloads.html]( http://www.vagrantup.com/downloads.html)

3. If you're running Windows you will need to install Cygwin.
       [https://cygwin.com/install.html](https://cygwin.com/install.html)
   - Try to install cygwin in a directory with no spaces in the name. So no “Program Files” or anything like that. The best location would be C:\Cygwin

   - **Make sure to install tools like : **
		- wget
		- curl
		- dos2unix
		- ruby

4. Install Git :  [http://git-scm.com/downloads](http://git-scm.com/downloads)
	- If  you're on Windows, during the install you'll  have the option to add Git  and its Linux-style command line tools to your system Path. If you already have Git installed, or you forgot to select this option upon installation, you’ll need to add Git’s /bin directory to your Path manually.
ie: `set PATH=%PATH%;/cygdrive/c/Program\ Files\ \(x86\)/Git/bin/`

    - If you're on OSX. The installer on the website seems to be broken. As a workaround, use homebrew to install Git.
        - install Homebrew : [http://brew.sh/](http://brew.sh/)
          `ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"`
        - install Git itself :
            `brew instal git`
5. Set up ssh keys:
	- `% ssh-keygen -t rsa`

	this will place both private and public keys to  ~/.ssh/id_rsa and ~/.ssh/id_rsa.pub  respectively.

   - Place the public key in the Git Server
     << this is still in the works  >>

6. Once everything is installed and configured <pre><code>git clone git@gitlab.com:leshiynyc/puppet-control.git
	cd puppet-control
	vagrant up puppetagent1
	vagrant ssh puppetagent1
    </code></pre>


- The repo above contains the 'Vagrantfile', which is the configuration file for vagrant as well as the following provisioning scripts for vagrant.

   <pre><code>   ( ./puppet-control/vagrant/fullstack.sh )
   ( ./puppet-control/vagrant/allinone.sh )</code></pre>


- To get Hiera to work on Vagrant w/o a Puppet Master
<pre><code>    vagrant ssh puppetagent1`
    sudo su -
    cp -v /vagrant/site/profile/files/hiera.yaml  /etc/puppetlabs/puppet/
    rm -rf /etc/puppetlabs/puppet/environments/production/
    ln -s /vagrant  /etc/puppetlabs/puppet/environments/production
    puppet apply -e  "include CLASS_NAME"</code></pre>

**CLASS_NAME is the class which uses hiera, ie 'profile::base::ntp'**
