# Puppet Enterprise 3-split stack

## Table of Contents

1. [Overview](#overview)
2. [Installation Procedure for Full Stack](#installation-procedure-for-full-stack)
    * [Install the Primary Master/CA](#1-install-the-primary-master-ca)
    * [Install the PuppetDB/PostgreSQL Server](#2-install-the-puppetdb-postgresql-server)
    * [Install the Console Server](#3-install-the-console-server)
3. [Testing](#testing)
    * [Vagrant Testing of Profiles](#vagrant-testing-of-profiles)
    * [Control Repository Testing in Vagrant](#control-repository-testing-in-vagrant)
    * [Control Repository Testing on Real Machines](#control-repository-testing-on-real-machines)

## Overview

This is a Puppet Enterprise 3.3 standard "split-install" stack, consisting of
three base servers:

1. Primary master/CA
2. PuppetDB/PostgreSQL
3. Console

There is also support for additional "compile masters"

| Hostname       | Description                      |
| -------------- | -------------------------------- |
| puppetmaster1  | Primary master and CA            |
| puppetdb1      | PuppetDB and PostgreSQL          |
| puppetconsole1 | Enterprise Console               |
| puppetmaster2  | Additional "compile-only" master |
| puppetagent1   | Standard PE agent for testing    |

In addition to testing the Puppet Enterprise stack, this Vagrant environment
includes a simple agent to use for local module development testing of
'profiles'.

## Installation Procedure for full stack

Under Vagrant instances, change to `/vagrant` to reach the control repository.

On "real" systems, you should clone the control repository to the system that
you're bootstrapping.

Answer files are located in `bootstrap/answers/`

### 1. Install the Primary Master/CA

Use the provided answer file to install Puppet Enterprise.  For example:

```shell
puppet-enterprise-installer -A ../../answers/ca.txt
```

#### Install pre-requisites

You'll need Git and r10k to bootstrap the CA properly.

```shell
yum install -y git

/opt/puppet/bin/gem install r10k
```

Once r10k is installed, you'll need to run it against the `Puppetfile` in the
control repository to populate a modules directory.  You should do this from
the root of the control repository.

```shell
r10k puppetfile install -v
```

#### Bootstrap it via Puppet

From within the top level of the control repository, use `puppet apply` to
apply the Puppet code for bootstrapping:

```shell
puppet apply -e 'include profile::puppet::ca,profile::puppet::master' \
  --modulepath=site:modules:/opt/puppet/share/puppet/modules
```

For an idea of what these two profiles do, view the source.  In short, they
will configure the CA autosigner to sign the PuppetDB and Console certificates
during their installation, install and manage r10k, configure Hiera, and
various other items.

Finally, you'll probably want to run r10k to synchronize your environments:

```shell
r10k deploy environment -pv
```

__Note:__ Your Puppet Master will need access to the Git repository, likely
by adding an SSH public key from the master to the remote repository. You'll
also need to ensure SSH has had a chance to accept the remote host's key.

#### Without the above step

If you don't do the "puppet apply" bit above, you'll need to __at least__ do
the following to ensure the PuppetDB and Console servers install successfully:

Edit `/etc/puppetlabs/puppet/autosign.conf` and add the following entries:

* The full certificate name of the PuppetDB server (e.g.
puppetdb1.cc.columbia.edu)
* The full certificate name of the Console server (e.g.
puppetconsole1.cc.columbia.edu)


### 2. Install the PuppetDB/PostgreSQL server

Use the provided answer file to install Puppet Enterprise.  For example:

```shell
puppet-enterprise-installer -A ../../answers/puppetdb.txt
```

#### Using alternate names (CNAMEs)

If you want to use a generic CNAME (non-specific address) to communicate with
PuppetDB services, you'll have to perform the following procedure.  During the
master's installation, for instance, if you configured it to use a generic
CNAME to communicate with the PuppetDB server.

The reason: the PE installer will use a single certificate name (defaulting to
the fqdn) for the PuppetDB role.  It does not ask if you would like alternate
names.  For security, the Puppet CA will not autosign certificates that contain
alternate names.  This would prevent a certificate that contained them from
being autosigned during installation, which would cause an installation failure.

To use alternative names, you must do this post-install.


Edit `/etc/puppetlabs/puppet/puppet.conf` and add the following under the
`[main]` section:

```
dns_alt_names = puppetdb1,puppetdb.cc.columbia.edu,puppetdb
```

Basically, you want to add the generic CNAMEs as alternate certificate names for
the PuppetDB server.  You cannot do this during installation.

On the CA server, clean the existing certificate for the PuppetDB server.  For
example:

```shell
puppet cert clean puppetdb1.cc.columbia.edu
```

Remove the existing SSL data on the PuppetDB server and run the Puppet agent
to create a new CSR (certificate signing request) with the altnames.

```shell
rm -rf /etc/puppetlabs/puppet/ssl
puppet agent -t
```

Now go sign the certificate on the CA, allowing the alt names:

```shell
puppet cert sign --allow-dns-alt-names puppetdb1.cc.columbia.edu
```

Then run the agent on the PuppetDB server again to retrieve the signed certificate:

```shell
puppet agent -t
```

Re-generate the internal PuppetDB certificates on the PuppetDB server:

```shell
/opt/puppet/sbin/puppetdb ssl-setup -f
```

Restart the `pe-puppetdb` service:

```shell
service pe-puppetdb restart
```

### 3. Install the Console server

Use the provided answer file to install Puppet Enterprise.  For example:

```shell
puppet-enterprise-installer -A ../../answers/console.txt
```

## Testing

### Vagrant Testing of Profiles

Profiles are Puppet manifests that implement a technology.  Basically, the
purpose of a profile is to "wrap" the individual component modules that
configure specific things.  Testing profiles can be a little different than
testing regular component modules.  Often, a profile will have several
dependency modules.  For example, a profile for "base linux" might implement
several things, such as ntp, sudoers, ssh, etc.  To make for a consistent
testing environment (consistent with your 'real' environments), we leverage
the control repository and r10k's module management to provide those dependencies.

You can use a regular agent for this.  The `puppetagent1` that's included, for
example.

#### 1. Bring up the test agent

```shell
vagrant up puppetagent1
```

This will bring up a basic CentOS instance, install a Puppet Enterprise agent,
configure Puppet's module path to find your modules, and run r10k to deploy
the modules that are listed in the control repository's `Puppetfile`

Once that's completed, you're able to test the individual profiles.

You should use Vagrant to SSH into the machine to conduct testing:

```shell
vagrant ssh puppetagent1
```

The control repository (this directory) will be available to the Vagrant
instance under `/vagrant/`

#### 2. Tests

Tests should be placed in the `tests/` directory.

Typically, these are simply declaring the profile that you want to test.
For example, to test the individual `profile::base::ntp` class:

```puppet
include profile::base::ntp
```

Then you can simply use `puppet apply` to test it:

You should use Vagrant to SSH into the machine to conduct testing:

```shell
vagrant ssh puppetagent1
```

The control repository (this directory) will be available to the Vagrant
instance under `/vagrant/`

#### 2. Tests

Tests should be placed in the `tests/` directory.

Typically, these are simply declaring the profile that you want to test.
For example, to test the individual `profile::base::ntp` class:

```puppet
include profile::base::ntp
```

Then you can simply use `puppet apply` to test it:

```shell
puppet apply /vagrant/tests/ntp.pp
```

_Note:_ You should run your tests as root!

__puppet apply__:

Puppet apply is not a full Puppet agent run.  That said, it's not communicating
with a master or other Puppet servers to compile its catalog - it's all local.
This is generally acceptable.  However, you may see warnings for things like
`storeconfigs`, which just indicates that a PuppetDB instance is unavailable.

If you need to test a full implementation that requires a full Puppet
infrastructure, you should use Puppet environments and test on a real agent.
Optionally, you can use this Vagrant environment to provide a full PE stack
with an agent to test with.

### Control Repository Testing in Vagrant

When you use the bootstrap procedure above, the "real" canonical control
repository will be synchronized to the Puppet master.  If you're doing
development and would like to test in Vagrant, you should do the following
on the master(s):

1. Remove the `/etc/puppetlabs/puppet/environments` directory that was
populated by r10k.
2. Symlink `/vagrant` to `/etc/puppetlabs/puppet/environments`

### Control Repository Testing on Real Machines

Branches of the control repository will become Puppet environments that agents
can run against.

1. Create a branch in the control repository
2. Ensure the canonical control repo on your Git server has the branch and the
code pushed to it.
3. Allow r10k to synchronize the code to your masters
4. Test agents by specifying an environment: `puppet agent -t --environment something`
