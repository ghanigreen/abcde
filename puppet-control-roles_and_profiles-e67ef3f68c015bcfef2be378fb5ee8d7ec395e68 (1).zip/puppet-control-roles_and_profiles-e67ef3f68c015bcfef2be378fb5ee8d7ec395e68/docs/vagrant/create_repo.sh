
#!/usr/bin/env bash

#### debug mode on/off
#  set -x


###  sets up a local yum repo 


REPO_DIR="/share/CentOS/6/local/X86_64/"
RPM_DIR="RPMS"
STORE="/vagrant/.yums/"


yum install -y createrepo


mkdir -p       $REPO_DIR/$RPM_DIR
createrepo     $REPO_DIR/$RPM_DIR

cp -v $STORE/*.rpm  $REPO_DIR/$RPM_DIR/ 
chmod -R o-w+r $REPO_DIR
createrepo --database   $REPO_DIR/$RPM_DIR/
cp -v $STORE/local.repo  /etc/yum.repos.d/
yum clean all 


