#!/bin/bash
## This script is only used by Vagrant for making our environment available
## with the right hostname resolutions and pre-downloads PE to share across
## the instances.  It's not used outside of Vagrant.
##
## This spins up a full split stack that resembles production

source /vagrant/bootstrap/answers/common.txt

## The version of PE to make available to in our Vagrant environment
PE_VERSION="3.3.2"

###########################################################
ANSWERS=$2
PE_URL="https://s3.amazonaws.com/pe-builds/released/${PE_VERSION}/puppet-enterprise-${PE_VERSION}-el-6-x86_64.tar.gz"
FILENAME=${PE_URL##*/}
DIRNAME=${FILENAME%*.tar.gz}
PE_INSTALLER="bootstrap/pe"

## A reasonable PATH
echo "export PATH=$PATH:/usr/local/bin:/opt/puppet/bin" >> /etc/bashrc

## Add host entries for each system
cat > /etc/hosts <<EOH
127.0.0.1 localhost localhost.localdomain localhost4 localhost4.localdomain
::1 localhost localhost.localdomain localhost6 localhost6.localdomain
###############################################################################
192.168.29.35 ${PRIMARY_MASTER}.${DOMAIN} ${PRIMARY_MASTER}
192.168.29.35 ${PUPPETDB_HOST}.${DOMAIN} ${PUPPETDB_HOST}
192.168.29.35 ${PUPPETCONSOLE_HOST}.${DOMAIN} ${PUPPETCONSOLE_HOST}

###############################################################################
### CNAMES
192.168.29.35 ${GENERIC_PUPPETCA}.${DOMAIN} ${GENERIC_PUPPETCA}
192.168.29.35 ${GENERIC_PUPPETMASTER}.${DOMAIN} ${GENERIC_PUPPETMASTER}
192.168.29.35 ${GENERIC_PUPPETDB}.${DOMAIN} ${GENERIC_PUPPETDB}
192.168.29.35 ${GENERIC_PUPPETCONSOLE}.${DOMAIN} ${GENERIC_PUPPETCONSOLE}

## This is for the simple agent for module testing
192.168.29.35 puppetagent1.vagrant.vm puppetagent1
192.168.29.35 testing.vagrant.vm testing

EOH

## Download and extract the PE installer
mkdir -p /vagrant/${PE_INSTALLER} || (echo "Could not create /vagrant/${PE_INSTALLER}"; exit 1)
cd /vagrant/${PE_INSTALLER}
if [ ! -f $FILENAME ]; then
  curl -O ${PE_URL} || (echo "Failed to download ${PE_URL}" && exit 1)
else
  echo "${FILENAME} already present"
fi

if [ ! -d ${DIRNAME} ]; then
  tar zxf ${FILENAME} || (echo "Failed to extract ${FILENAME}" && exit 1)
else
  echo "${DIRNAME} already present"
fi

## Make sure iptables is stopped in our Vagrant instance.
printf "\n==> Stopping iptables\n\n"
service iptables stop

## Install PE with a specified answer file
if [ ! -d '/opt/puppet/' ]; then
  # Assume puppet isn't installed
  echo "==> Installing PE with answerfile: ${ANSWERS}.txt"
  /vagrant/${PE_INSTALLER}/${DIRNAME}/puppet-enterprise-installer \
    -a /vagrant/bootstrap/answers/${ANSWERS}.txt
else
  echo "/opt/puppet exists. Assuming Puppet is already installed."
fi

## Install some prerequisites
/usr/bin/yum install -y git
/opt/puppet/bin/gem install r10k

/opt/puppet/bin/puppet config set --section main environmentpath \
  /etc/puppetlabs/puppet/environments

/opt/puppet/bin/puppet config set --section main basemodulepath \
  /vagrant/site:/vagrant/modules:/etc/puppetlabs/puppet/modules:/opt/puppet/share/puppet/modules

## Stub in the Hiera config file for local agent testing (puppet apply)
echo "==> Configuring Hiera"
cp -f /vagrant/site/profile/files/hiera.yaml /etc/puppetlabs/puppet/hiera.yaml

## Create a production environment.  It'll be empty, but it will prevent
## Puppet from complaining
mkdir -p /etc/puppetlabs/puppet/environments/production

echo "==> Linking /vagrant to /etc/puppetlabs/puppet/environments/production"
ln -s /vagrant /etc/puppetlabs/puppet/environments/production

## Use the control repo for bootstrapping
echo "==> Executing r10k. This may take a couple of minutes..."
## Change to the vagrant directory.  A 'puppetfile' run of r10k looks
## for a file in the CWD called "Puppetfile"
cd /vagrant
/opt/puppet/bin/r10k puppetfile install -v

echo "========================================================================"
echo "The agent is provisioned and ready for testing."
echo "========================================================================"
echo
echo "To test:"
echo "  - Login to this machine (vagrant ssh ${1})"
echo "  - Run 'puppet apply' against your test in /vagrant/tests"
echo "  - You can also do something like:"
echo "        puppet apply -e 'include profile::mytest'"
echo
echo "Testing Puppetfile changes here:"
echo "  - If you make modifications to the Puppetfile and want to keep testing,"
echo "    simply run:"
echo "        r10k puppetfile install -v"
echo "    from the /vagrant directory."
echo
echo "Testing an agent with a master:"
echo "  - If you need to test with a agent running against a master, you can"
echo "    spin up the PE stack and run this agent against it.  Refer to the"
echo "    Readme.md file for information on bootstrapping this."
echo
echo "Testing your own component modules:"
echo "  - You can place your own component modules inside the modules/"
echo "    directory to test them on the agent.  Do note that modules/ will be"
echo "    ignored by Git in the control repository, so you should keep your"
echo "    module outside of here.  Use it to do temporary testing."
echo "  - You can also setup a new Vagrant environment for your component"
echo "    module."
echo
echo "========================================================================"
echo "Complete?"
