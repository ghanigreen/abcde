# CUIT Puppet Control

  - [Design Goals](#design-goals)
  - [Installation](#installation)
  - [Vagrant](#vagrant)
	  - [The Fine Print](#the-fine-print)
	  - [Usage](#usage)
		  - [Setting role and tier](#setting-role-and-tier)
		  - [Understanding the hiera search order](#understanding-the-hiera-search-order)
          - [Exposing virtualbox guest ports to your host](#exposing-virtualbox-guest-ports-to-your-host)
          - [Messing with the guest system clock](#messing-with-the-guest-system-clock)
		  - [Setting Puppet options](#setting-puppet-options)
		  - [Running an extra Vagrant script provisioner](#running-an-extra-vagrant-script-provisioner)
      - [Making a CUIT-custom virtualbox image from RHEL DVD ISOs](#making-a-cuit-custom-virtualbox-image-from-rhel-dvd-isos)
  - [Finessing your YAML](#finessing-your-yaml)
  - [Contributing](#contributing)
  - [History](#history)
  - [Credits](#credits)
  - [License](#license)

This is CUIT's "R10K style" Puppet code repository. It contains everything related to Puppet infrastructure.

## Design Goals

[Puppet Design Document](https://docs.google.com/document/d/1aRPE4JtdJ97Wf7NUyw9EDw3F1hroSjtC70mepEVNETU/edit#heading=h.8li426r7vwzw)

---

## Installation

```
$ gem install puppet-lint yaml-lint rails-erb-lint
$ git clone git@gitlab.cc.columbia.edu:cuit-puppet/puppet-control.git
$ cd puppet-control
$ ln -s ../../docs/hooks/pre-commit .git/hooks/
```

---

## Vagrant
This repository contains a Vagrantfile that is configured to use Vagrant's [puppet apply](https://www.vagrantup.com/docs/provisioning/puppet_apply.html) provisioner, plus the [vagrant-r10k](https://github.com/jantman/vagrant-r10k) plugin.

### The Fine Print

  * `Vagrantfile` is configured to use Redhat Enterprise Linux 6.9 (`cuit/rhel69-cuit`).
  * You must be connected to CUIT network (e.g. via VPN)
  * Note that Vagrant has its own hiera level and [overwrites a few values](hieradata/vagrant/vagrant.yaml)
  * Your vagrantbox has access to CUIT's Satellite server and by default is subscribed similarly to the way CI boxes are.
  * These profiles are disabled in [base.pp](site/profile/base/base.pp):
    * Hyperic
    * Sumo
	* Tripwire
    * NFS mounts
  * Your `.gitconfig` and `.ssh/id_rsa` are installed in the vagrant box user's home directory to facilitate git usage when doing `vagrant ssh`.
  
### Usage
  1. `vagrant up` will provision a basic CUIT host
  1. Make your changes to .pp, .yaml, etc. files
  1. To apply the changes you've made, run `vagrant provision --provision-with puppet`. This will re-run vagrant's *puppet apply provisioner* to an already up'd vagrantbox. Run `vagrant provision` as much as you'd like.
  Note that if you leave off the `--provision-with puppet` then the shell provisioner(s) will also run.
  In general this is only needed for the initial `vagrant up` and wastes some time if repeated.

#### Setting role and tier

Facts like `$::app_role` and `$::app_tier` can be set via shell environment variables while running `vagrant provision`. For example:

```
APP_TIER=dev APP_ROLE=mygroup-web vagrant provision --provision-with puppet
```

#### Understanding the hiera search order

Here's the current hiera search hierarchy used here. This matches the production hiearchy *with the exception*
of the vagrant-specific overrides.
```
:hierarchy:
- node/%{clientcert}                # Items that are specific to just one single node
- vagrant/%{::vagrant}              # Items that are generally vagrant-specific
- app_tier/%{app_tier}/%{app_role}	# Items that differ based on what tier the app is running in
- app_tier/%{app_tier}              # Items that are common among each app tier
- app_role/%{app_role}				# Items that differ based on the application being installed on the host
- datacenter/%{datacenter}			# Items that differ based on physical location
- common/net                        # Network zone/subnet definitions
- common/common                     # Items that are shared among ALL hosts
```

#### Exposing virtualbox guest ports to your host

You can also set which guest ports forward to host ports by setting environment variables
that match `APP_PORT`. For example, to forward guest port 9999 to host port 1234 and
port 80 to 8080:
```
APP_PORT1=9999:1234 APP_PORT2=80:8080 vagrant up
```
*This only works for `vagrant up`.* And, you only have to set the `APP_PORT` variables
for the `vagrant up`; the port forwarding sticks around until the next `vagrant destroy`
and `vagrant up`.

#### Messing with the guest system clock

Sometimes you want to fake what time it is when testing.
Set env variable FAKE_CLOCK to disable syncing the host and guest clocks. You'll also
need to turn off NTP and set the clock back in the guest.


```bash
puppet-control$ FAKE_CLOCK=1 vagrant up
puppet-control$ vagrant ssh
[vagrant@localhost ~]$ sudo service ntpd stop
[vagrant@localhost ~]$ sudo date --set "12/12/2016"
```
and restart your service.

#### Setting Puppet options

If you want to set non-default Puppet options for the Puppet provisioner, set the `PUPPET_OPTS` 
environment variable. Some common options are `--strict_variables`, `--debug`, and `--verbose`.

```bash
PUPPET_OPTS="--strict_variables" vagrant provision --provision-with puppet
```

#### Running an extra Vagrant script provisioner

Sometimes you may want to run an extra provisioner script to further automate your dev environment setup or to
run through some alternative scenarios. Set the `EXTRA` environment variable with the relative
path to the extra provisioner script. If you want, you can run just the extra script by specifying
that as the provisioner:

```bash
EXTRA=extra.d/dev-oauth-server.sh vagrant provision --provision-with extra
```

### Making a CUIT-custom virtualbox image from RHEL DVD ISOs

See the [Packer instructions](pack-box/README.md) which documents how to make the cuit/rhel69 or cuit/rhel74
Virtual box image that is referenced in the Vagrantfile. This is a Puppet-configured `base` box that will speed
up bootstrapping.

## Finessing your YAML

To avoid having to duplicate data in your hieradata [YAML](yaml.org) files, you can use various constructs such as
`&`, `*`, and `<< :` to label and then reuse values in the same YAML file. For example, you may have a
map with many keys which you want to reuse, but with only one or two small changes as in this example where
we define the `&idp` tag and then duplicate the map with a couple of overrides (using `<< : *idp`):

```
# we have the same IdP twice with a different virtual ID which selects MFA or not
pingfederate::saml2_idp:
  - &idp
    virtual: columbia-ping:urn:saml2
    name: Columbia University
...
    oauth_map:
      - name: USER_KEY
        type: ASSERTION
        value: SAML_SUBJECT
...
  - << : *idp
    virtual: columbia-ping-mfa:urn:saml2
    name: Columbia University Duo MFA
```

Use [testyaml.py](testyaml.py) to test your yaml keys. Here's a sample invocation:

```
puppet-control$ python testyaml.py hieradata/app_role/oauth-server.yaml pingfederate::saml2_idp
pingfederate::saml2_idp
[
  {
    "oauth_map": [
      {
        "type": "ASSERTION", 
        "name": "USER_KEY", 
        "value": "SAML_SUBJECT"
      }, 
...
    "name": "Columbia University", 
...
    "virtual": "columbia-ping:urn:saml2", 
...
  {
    "oauth_map": [
      {
        "type": "ASSERTION", 
        "name": "USER_KEY", 
        "value": "SAML_SUBJECT"
      }, 
...
    "name": "Columbia University Duo MFA", 
...
    "virtual": "columbia-ping-mfa:urn:saml2", 
...
  }
]
```

Here's another example of reusing network CIDR blocks in [common/net.yaml](hieradata/common/net.yaml) using
simple `&` and `*`:
```
net::ip4::columbia::morningside::datacenter::CUIT::CI-EZ: &EZM
  - '128.59.41.0/24'                                      # CI-EZ Vlan 41
  - '128.59.94.0/23'
  - '128.59.213.0/24'                                     # AIS Computer Center Ethernet
  - '128.59.214.0/24'                                     # MALTS Computer Center Ethernet
  - '128.59.215.0/24'                                     # Enterprise_Zone_Vlan_215
net::ip4::columbia::syracuse::datacenter::CUIT::CI-EZ: &EZS
  - '207.10.140.0/24'                                     # SYRACUSE_CI_EZ_Vlan_291
net::ip4::columbia::all::datacenter::CUIT::CI-EZ: &EZA
  - *EZM
  - *EZS
```

```
puppet-control$ python testyaml.py hieradata/common/net.yaml net::ip4::columbia::all::datacenter::CUIT::CI-EZ
net::ip4::columbia::all::datacenter::CUIT::CI-EZ
[
  [
    "128.59.41.0/24", 
    "128.59.94.0/23", 
    "128.59.213.0/24", 
    "128.59.214.0/24", 
    "128.59.215.0/24"
  ], 
  [
    "207.10.140.0/24"
  ]
]

```


## Contributing

1. Become a developer on the puppet-control repo, or clone it.
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a merge request.

## History

  * Updates around July 2017 to add EXTRA and some other documentation improvements.
  * Updated in April 2017 to switch over to a RHEL 6.9 CUIT "base" box (rather than CentOS)
  * Updated in January 2017 to make vagrant work again (and better, too!)
  * Refactored in September 2015 using method of Roles, Profiles, and Hiera
  * Refactored in April 2015 using method of `hiera_include()` and `create_resources()`
  * Original implementation is dated Oct 2014-Mar 2015 and was archived in branches `old_dev` and `old_production`

## Credits

  * Stas Khromoy (sk4020@columbia.edu)
  * Sean Kaynes (sk4052@columbia.edu)
  * Vincent Lu (vl2352@columbia.edu)
  * Alan Crosswell (alan@columbia.edu)

## License

This repository is not to be shared outside of CUIT.
